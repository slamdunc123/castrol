self.__precacheManifest = [
  {
    "revision": "7378a1bfe86f9313bf8b",
    "url": "/castrol/static/css/main.04158dc1.chunk.css"
  },
  {
    "revision": "7378a1bfe86f9313bf8b",
    "url": "/castrol/static/js/main.859d6898.chunk.js"
  },
  {
    "revision": "9afba600b4bc5f96f4f5",
    "url": "/castrol/static/js/runtime~main.f9b21eeb.js"
  },
  {
    "revision": "0a44a87308b45bf326a7",
    "url": "/castrol/static/js/2.daaef78e.chunk.js"
  },
  {
    "revision": "f3d0286d7e6a566e913379fbbf4a7eda",
    "url": "/castrol/static/media/medium.f3d0286d.png"
  },
  {
    "revision": "e343220fbed54f6a0cbfb93768190abe",
    "url": "/castrol/static/media/heavy.e343220f.png"
  },
  {
    "revision": "3f7986f843e1bb249f83a02d3c503fc0",
    "url": "/castrol/static/media/castrol.3f7986f8.png"
  },
  {
    "revision": "6a9a13f7f9d918810aff5ee7d906f0ee",
    "url": "/castrol/index.html"
  }
];